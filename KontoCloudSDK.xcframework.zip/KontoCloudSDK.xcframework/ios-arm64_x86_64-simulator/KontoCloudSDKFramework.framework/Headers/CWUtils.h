//
//  CWUtils.h
//  KontoCloudSDK
//
//  Created by Nick on 14.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CWUtils : NSObject

+ (NSString *)genRandomIdWithLength:(int)length;
+ (NSString *)getCurLocale;
+ (NSString *)getCurLocaleFull;
+ (NSString *)hexStringForColor:(UIColor *)color;
+ (NSString *)LStr:(NSString *)str;

@end
