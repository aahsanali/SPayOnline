//
//  CWGetAccountStateResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWGetAccountStateResponse : CWResponseBase

@property (nonatomic) NSString *statusCode;

- (BOOL)isUserLocked;
- (BOOL)isUserActive;

@end
