//
//  CWAuthenticationAPI.h
//  KontoCloudSDK
//
//  Created by Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWBaseAPI.h"

@class CWAccessTokenResponse;

@interface CWAuthenticationAPI : CWBaseAPI

- (void)getAccessTokenWithUserName:(NSString *)userName password:(NSString *)password grantType:(NSString *)grantType completion:(void (^)(NSError *error, CWAccessTokenResponse *response))completionBlock;
- (void)getRefreshTokenWithToken:(NSString *)refreshToken grantType:(NSString *)grantType completion:(void (^)(NSError *error, CWAccessTokenResponse *response))completionBlock;

@end
