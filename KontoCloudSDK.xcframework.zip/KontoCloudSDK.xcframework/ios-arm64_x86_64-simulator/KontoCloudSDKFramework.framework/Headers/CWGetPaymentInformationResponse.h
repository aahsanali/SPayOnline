//
//  CWGetPaymentInformationResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWGetPaymentInformationResponse : CWResponseBase

@property (nonatomic) NSString *uniqueReference;
@property (nonatomic) NSString *initiatorName;
@property (nonatomic) NSNumber *presentationAmount;
@property (nonatomic) NSString *presentationCurrCode;
@property (nonatomic) NSString *presentationUsage;
@property (nonatomic) NSString *customerFullName;
@property (nonatomic) NSString *addr1;
@property (nonatomic) NSString *addr2;
@property (nonatomic) NSString *city;
@property (nonatomic) NSString *state;
@property (nonatomic) NSString *country;
@property (nonatomic) NSString *countryCode;
@property (nonatomic) NSString *postCode;

@end
