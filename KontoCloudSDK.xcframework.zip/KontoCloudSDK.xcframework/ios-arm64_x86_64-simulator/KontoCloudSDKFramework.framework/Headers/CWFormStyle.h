//
//  CWFormStyle.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 23.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef NS_OPTIONS(NSInteger, CWTextStyle) {
    CWTextStyle_REGULAR = 1,
    CWTextStyle_BOLD = 1 << 1,
    CWTextStyle_ITALIC = 1 << 2
};

@interface CWFontStyle : NSObject

@property (nonatomic) NSString *fontName;
@property (nonatomic) CGFloat textSize;
@property (nonatomic) UIColor *textColor;
@property (nonatomic) CWTextStyle textStyle;

@end

@interface CWBorderSideStyle : NSObject

@property (nonatomic) CGFloat size;
@property (nonatomic) UIColor *color;

@end

@interface CWBorderStyle : NSObject

@property (nonatomic) CWBorderSideStyle *leftBorderStyle;
@property (nonatomic) CWBorderSideStyle *rightBorderStyle;
@property (nonatomic) CWBorderSideStyle *topBorderStyle;
@property (nonatomic) CWBorderSideStyle *bottomBorderStyle;

@end

@interface CWInputStyle : NSObject

@property (nonatomic) CWFontStyle *labelFontStyle;
@property (nonatomic) CWFontStyle *editTextFontStyle;
@property (nonatomic) CWBorderStyle *editTextBorderStyle;
@property (nonatomic) CWFontStyle *validationHintFontStyle;

//default YES
@property (nonatomic) BOOL isPlaceholderVisible;

@end

@interface CWFormStyle : NSObject

@property (nonatomic) CWFontStyle *labelFontStyle DEPRECATED_MSG_ATTRIBUTE("use paymentFormInputStyle.labelFontStyle instead");
@property (nonatomic) CWFontStyle *editTextFontStyle DEPRECATED_MSG_ATTRIBUTE("use paymentFormInputStyle.editTextFontStyle instead");
@property (nonatomic) CWBorderStyle *editTextBorderStyle DEPRECATED_MSG_ATTRIBUTE("use paymentFormInputStyle.editTextBorderStyle instead");
@property (nonatomic) CWFontStyle *validationHintFontStyle DEPRECATED_MSG_ATTRIBUTE("use paymentFormInputStyle.validationHintFontStyle instead");
@property (nonatomic) BOOL isPlaceholderVisible DEPRECATED_MSG_ATTRIBUTE("use paymentFormInputStyle.isPlaceholderVisible instead");


//used to set styles for all inputs
@property (nonatomic) CWInputStyle *paymentFormInputStyle;

//used to set styles for specific input
@property (nonatomic) CWInputStyle *paymentFormCardNumberInputStyle;
@property (nonatomic) CWInputStyle *paymentFormExpiryDateInputStyle;
@property (nonatomic) CWInputStyle *paymentFormCardHolderInputStyle;
@property (nonatomic) CWInputStyle *paymentFormCvvInputStyle;
@property (nonatomic) CWInputStyle *paymentFormAccountHolderInputStyle;
@property (nonatomic) CWInputStyle *paymentFormIbanInputStyle;

// default NO
@property (nonatomic) BOOL paymentFormShowCVVHint;

@end
