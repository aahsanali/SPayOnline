//
//  CWAuthorizeResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWAuthorizeResponse : CWResponseBase

@property (nonatomic) NSString *programAccno;
@property (nonatomic) NSString *accno;
@property (nonatomic) NSString *uniqueReference;
@property (nonatomic) NSString *paymentOptionCode;
@property (nonatomic) NSString *storedPaymentOptionReference;
@property (nonatomic) NSString *invoiceReference;
@property (nonatomic) NSString *channelProductReference;
@property (nonatomic) NSNumber *presentationAmount;
@property (nonatomic) NSString *presentationCurrCode;
@property (nonatomic) NSString *presentationUsage;
@property (nonatomic) NSNumber *processedAmount;
@property (nonatomic) NSString *processedCurrCode;
@property (nonatomic) NSString *custom1;
@property (nonatomic) NSString *custom2;
@property (nonatomic) NSString *custom3;
@property (nonatomic) NSString *statusCode;
@property (nonatomic) NSString *statusReason;

@end
