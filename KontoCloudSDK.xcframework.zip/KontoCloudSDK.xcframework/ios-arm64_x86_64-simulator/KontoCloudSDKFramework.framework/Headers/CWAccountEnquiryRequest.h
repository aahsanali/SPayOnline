//
//  CWAccountEnquiryRequest.h
//  KontoCloudSDK
//
//  Created by Nick on 14.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWAccountEnquiryRequest : CWRequestBase

@property (nonatomic) NSString *accnoType;
@property (nonatomic) NSDate *startDate;
@property (nonatomic) NSDate *endDate;
@property (nonatomic) NSInteger top;
@property (nonatomic) NSInteger skip;
@property (nonatomic) NSString *sortDirection;

@end
