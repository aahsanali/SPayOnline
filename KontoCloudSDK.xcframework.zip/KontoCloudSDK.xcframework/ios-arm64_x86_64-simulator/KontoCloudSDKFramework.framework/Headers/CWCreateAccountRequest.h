//
//  CWCreateAccountRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWAccountRequest.h"

@interface CWCreateAccountRequest : CWAccountRequest

@property (nonatomic) NSString  *accountApplicationFlowCode;
@property (nonatomic) NSString  *currCode;
@property (nonatomic) NSDate    *validFrom;
@property (nonatomic) NSDate    *validUntil;
@property (nonatomic) NSString  *loginID;
@property (nonatomic) NSString  *placeOfBirth;
@property (nonatomic) NSString  *password;
@property (nonatomic) NSString  *occupation;
@property (nonatomic) NSString  *nationality;
@property (nonatomic) NSString  *identificationDocumentType;
@property (nonatomic) NSString  *identityNumber;
@property (nonatomic) NSString  *documentIssuingCountryCode;
@property (nonatomic) NSDate    *dateOfExpiry;
@property (nonatomic) NSString  *sourceOfWealth;
@property (nonatomic) NSString  *sourceOfFunds;
@property (nonatomic) BOOL      isPep;
@property (nonatomic) BOOL      isBusinessUser;
@property (nonatomic) NSString  *businessCompanyRegistrationCountryCode;

@end
