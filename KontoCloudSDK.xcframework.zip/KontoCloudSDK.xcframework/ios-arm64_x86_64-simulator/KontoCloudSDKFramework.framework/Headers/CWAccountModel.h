//
//  CWAccountModel.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWAccountModel : NSObject

@property (nonatomic) NSString *programAccno;
@property (nonatomic) NSString *currencyCode;

- (instancetype)initWithDictionary:(NSDictionary *)dict;

- (BOOL)isDefaultFeeAccount;

@end
