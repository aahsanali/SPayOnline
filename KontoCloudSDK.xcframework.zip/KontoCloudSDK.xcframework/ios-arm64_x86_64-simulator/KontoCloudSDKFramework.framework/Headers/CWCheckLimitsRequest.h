//
//  CWCheckLimitsRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWCheckLimitsRequest : CWRequestBase

@property (nonatomic) NSString *paymentOptionCode;
@property (nonatomic) NSString *storedPaymentOptionReference;

- (instancetype)initWithAccnoType:(NSString *)accnoType transactionTypeCode:(NSString *)transactionTypeCode amount:(NSNumber *)amount currCode:(NSString *)currCode;

@end
