//
//  CWBaseAPI.h
//  KontoCloudSDK
//
//  Created by Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWTransportLayer.h"

@interface CWBaseAPI : NSObject

@property (nonatomic, readonly) CWTransportLayer *transportLayer;

- (instancetype)initWithTransportLayer:(CWTransportLayer *)transportLayer;

@end
