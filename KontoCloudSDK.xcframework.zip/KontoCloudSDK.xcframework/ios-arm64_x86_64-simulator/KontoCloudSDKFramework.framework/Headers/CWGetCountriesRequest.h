//
//  CWGetCountriesRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWGetCountriesRequest : CWRequestBase

@property (nonatomic) BOOL onlyProgramCountries;

@end
