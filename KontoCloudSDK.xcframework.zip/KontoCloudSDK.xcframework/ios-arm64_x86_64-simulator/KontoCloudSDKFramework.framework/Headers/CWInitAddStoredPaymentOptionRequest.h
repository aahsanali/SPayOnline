//
//  CWInitAddStoredPaymentOptionRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWInitAddStoredPaymentOptionRequest : CWRequestBase

@property (nonatomic) NSString *mandateReference;
@property (nonatomic) NSDate   *mandateSignedDate;
@property (nonatomic) NSDictionary *criteria;
@property (nonatomic) BOOL useDifferentBillingAddress;
@property (nonatomic) NSString *customerFullName;
@property (nonatomic) NSString *addr1;
@property (nonatomic) NSString *addr2;
@property (nonatomic) NSString *addr3;
@property (nonatomic) NSString *houseNumber;
@property (nonatomic) NSString *city;
@property (nonatomic) NSString *state;
@property (nonatomic) NSString *countryCode;
@property (nonatomic) NSString *postCode;
@property (nonatomic) NSString *custom1;
@property (nonatomic) NSString *custom2;
@property (nonatomic) NSString *custom3;
@property (nonatomic) NSString *externalChannelReference;
@property (nonatomic) NSString *emailAddress;


- (instancetype)initWithAccnoType:(NSString *)accnoType paymentOptionCode:(NSString *)paymentOptionCode;

@end
