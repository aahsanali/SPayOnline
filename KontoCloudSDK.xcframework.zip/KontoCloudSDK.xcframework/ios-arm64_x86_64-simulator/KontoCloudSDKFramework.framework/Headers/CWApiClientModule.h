//
//  CWApiClientModule.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWAccessTokenProvider.h"
#import "CWApiClientSettingsInterface.h"

@class CWAccountAPI;
@class CWAuthenticationAPI;
@class CWPaymentAPI;
@class CWSettingsAPI;
@class CWUserAPI;

@interface CWApiClientModule : NSObject

@property (nonatomic, readonly) CWAccountAPI *accountAPI;
@property (nonatomic, readonly) CWAuthenticationAPI *authenticationAPI;
@property (nonatomic, readonly) CWPaymentAPI *paymentAPI;
@property (nonatomic, readonly) CWSettingsAPI *settingsAPI;
@property (nonatomic, readonly) CWUserAPI *userAPI;

- (instancetype)initWithApiAccessTokenProvider:(id <CWAccessTokenProvider>)accessTokenProvider settings:(id <CWApiClientSettingsInterface>)setting;

@end
