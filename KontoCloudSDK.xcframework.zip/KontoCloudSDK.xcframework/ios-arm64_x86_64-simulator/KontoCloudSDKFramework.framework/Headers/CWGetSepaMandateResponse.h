//
//  CWGetSepaMandateResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWGetSepaMandateResponse : CWResponseBase

@property (nonatomic) NSString *fileData;

@end
