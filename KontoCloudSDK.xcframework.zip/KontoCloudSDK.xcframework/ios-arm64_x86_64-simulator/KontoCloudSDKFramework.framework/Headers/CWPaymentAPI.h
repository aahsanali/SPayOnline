//
//  CWPaymentAPI.h
//  KontoCloudSDK
//
//  Created by Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWBaseAPI.h"

@class CWAuthorizeRequest;
@class CWAuthorizeResponse;
@class CWCaptureRequest;
@class CWCaptureResponse;
@class CWCancelRequest;
@class CWCancelResponse;
@class CWPayToAccountRequest;
@class CWPayToAccountResponse;
@class CWKcCompleteAuthorizeRequest;
@class CWKcCompleteAuthorizeResponse;
@class CWGetPaymentInformationRequest;
@class CWGetPaymentInformationResponse;
@class CWInitAuthorizeRequest;
@class CWInitAuthorizeResponse;
@class CWCompleteAuthorizeRequest;
@class CWCompleteAuthorizeResponse;

@interface CWPaymentAPI : CWBaseAPI

- (void)initAuthorize:(CWInitAuthorizeRequest *)request completion:(void (^)(NSError *error, CWInitAuthorizeResponse *response))completionBlock;
- (void)completeAuthorize:(CWCompleteAuthorizeRequest *)request uniqueReference:(NSString *)uniqueReference completion:(void (^)(NSError *error, CWCompleteAuthorizeResponse *response))completionBlock;
- (void)authorize:(CWAuthorizeRequest *)request completion:(void (^)(NSError *error, CWAuthorizeResponse *response))completionBlock;
- (void)capture:(CWCaptureRequest *)request uniqueReference:(NSString *)uniqueReference completion:(void (^)(NSError *error, CWCaptureResponse *response))completionBlock;
- (void)cancel:(CWCancelRequest *)request uniqueReference:(NSString *)uniqueReference completion:(void (^)(NSError *error, CWCancelResponse *response))completionBlock;
- (void)payToAccount:(CWPayToAccountRequest *)request completion:(void (^)(NSError *error, CWPayToAccountResponse *response))completionBlock;
- (void)kcCompleteAuthorize:(CWKcCompleteAuthorizeRequest *)request uniqueReference:(NSString *)uniqueReference completion:(void (^)(NSError *error, CWKcCompleteAuthorizeResponse *response))completionBlock;
- (void)getPaymentInformation:(CWGetPaymentInformationRequest *)request uniqueReference:(NSString *)uniqueReference completion:(void (^)(NSError *error, CWGetPaymentInformationResponse *response))completionBlock;


@end
