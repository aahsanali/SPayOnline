//
//  CWGetProgramAccountsResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"
#import "CWAccountModel.h"

@interface CWGetProgramAccountsResponse : CWResponseBase

@property (nonatomic) NSArray <CWAccountModel *> *accounts;

@end
