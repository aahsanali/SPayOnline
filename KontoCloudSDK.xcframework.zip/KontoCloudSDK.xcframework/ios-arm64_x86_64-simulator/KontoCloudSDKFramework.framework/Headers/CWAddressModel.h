//
//  CWAddressModel.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWAddressModel : NSObject

@property (nonatomic) NSString *fullName;
@property (nonatomic) NSString *addr1;
@property (nonatomic) NSString *addr2;
@property (nonatomic) NSString *city;
@property (nonatomic) NSString *state;
@property (nonatomic) NSString *countryName;
@property (nonatomic) NSString *countryCode;
@property (nonatomic) NSString *postCode;

- (instancetype)initWithDictionary:(NSDictionary *)dict;

@end
