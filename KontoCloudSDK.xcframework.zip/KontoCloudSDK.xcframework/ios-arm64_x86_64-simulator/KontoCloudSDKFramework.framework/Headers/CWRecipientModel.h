//
//  CWRecipientModel.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWRecipientModel : NSObject

@property (nonatomic) NSString *accno;
@property (nonatomic) NSString *fullName;
@property (nonatomic) NSString *emailAddress;

- (instancetype)initWithDictionary:(NSDictionary *)dict;

- (NSInteger)frequency;

@end
