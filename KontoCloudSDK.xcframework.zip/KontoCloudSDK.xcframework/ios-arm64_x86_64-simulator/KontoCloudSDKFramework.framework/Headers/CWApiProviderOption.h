//
//  CWApiProviderOption.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWAccessTokenProvider.h"

@interface CWApiProviderOption : NSObject

@property (nonatomic) NSString *url;
@property (nonatomic) NSString *programCode;
@property (nonatomic) NSString *partnerReferencePrefix;
@property (nonatomic) id <CWAccessTokenProvider> accessTokenProvider;

@end
