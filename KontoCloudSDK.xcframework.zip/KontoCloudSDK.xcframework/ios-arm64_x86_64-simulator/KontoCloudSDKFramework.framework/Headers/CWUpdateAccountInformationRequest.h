//
//  CWUpdateAccountInformationRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWAccountRequest.h"

@interface CWUpdateAccountInformationRequest : CWAccountRequest

@property (nonatomic) NSString *accnoType;
@property (nonatomic) NSString *culture;
@property (nonatomic) NSString *timeZone;
@property (nonatomic) BOOL notifyUser;

@end
