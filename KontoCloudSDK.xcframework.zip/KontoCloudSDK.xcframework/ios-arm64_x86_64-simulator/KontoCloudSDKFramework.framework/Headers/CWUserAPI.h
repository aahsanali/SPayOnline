//
//  CWUserAPI.h
//  KontoCloudSDK
//
//  Created by Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWBaseAPI.h"

@class CWResponseBase;

@class CWChangePasswordRequest;
@class CWSendPasswordResetCodeRequest;
@class CWSendPasswordResetCodeResponse;
@class CWCheckUserUniquenessRequest;
@class CWCheckUserUniquenessResponse;
@class CWValidatePasswordRequest;
@class CWGetSecondaryEmailsRequest;
@class CWGetSecondaryEmailsResponse;
@class CWCreateSecondaryEmailRequest;
@class CWEditSecondaryEmailRequest;
@class CWDeleteSecondaryEmailRequest;
@class CWSetMainEmailRequest;

@interface CWUserAPI : CWBaseAPI

- (void)sendPasswordResetCode:(CWSendPasswordResetCodeRequest *)request userId:(NSString *)userId completion:(void (^)(NSError *error, CWSendPasswordResetCodeResponse *response))completionBlock;
- (void)changePassword:(CWChangePasswordRequest *)request userId:(NSString *)userId completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)checkUserUniqueness:(CWCheckUserUniquenessRequest *)request userId:(NSString *)userId completion:(void (^)(NSError *error, CWCheckUserUniquenessResponse *response))completionBlock;
- (void)validatePassword:(CWValidatePasswordRequest *)request completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)getSecondaryEmails:(CWGetSecondaryEmailsRequest *)request userId:(NSString *)userId completion:(void (^)(NSError *error, CWGetSecondaryEmailsResponse *response))completionBlock;
- (void)createSecondaryEmail:(CWCreateSecondaryEmailRequest *)request userId:(NSString *)userId completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)editSecondaryEmail:(CWEditSecondaryEmailRequest *)request userId:(NSString *)userId completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)deleteSecondaryEmail:(CWDeleteSecondaryEmailRequest *)request userId:(NSString *)userId completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)setMainEmail:(CWSetMainEmailRequest *)request userId:(NSString *)userId completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;

@end
