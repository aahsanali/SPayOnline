//
//  CWAccountRequest.h
//  KontoCloudSDK
//
//  Created by Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWAccountRequest : CWRequestBase

@property (nonatomic) NSString  *title;
@property (nonatomic) NSString  *lastName;
@property (nonatomic) NSString  *firstName;
@property (nonatomic) NSString  *addr1;
@property (nonatomic) NSString  *addr2;
@property (nonatomic) NSString  *city;
@property (nonatomic) NSString  *state;
@property (nonatomic) NSString  *countryCode;
@property (nonatomic) NSString  *postCode;
@property (nonatomic) NSDate    *dob;
@property (nonatomic) NSString  *landlinePhone;
@property (nonatomic) NSString  *mobilePhone;
@property (nonatomic) NSString  *emailAddress;
@property (nonatomic) BOOL      useDifferentCorrespondenceAddress;
@property (nonatomic) NSString  *correspondenceAddr1;
@property (nonatomic) NSString  *correspondenceAddr2;
@property (nonatomic) NSString  *correspondenceCity;
@property (nonatomic) NSString  *correspondenceState;
@property (nonatomic) NSString  *correspondenceCountryCode;
@property (nonatomic) NSString  *correspondencePostCode;
@property (nonatomic) NSString  *businessCompanyName;
@property (nonatomic) NSString  *businessCompanyType;
@property (nonatomic) NSString  *businessAddr1;
@property (nonatomic) NSString  *businessAddr2;
@property (nonatomic) NSString  *businessCity;
@property (nonatomic) NSString  *businessPostCode;
@property (nonatomic) NSString  *businessCountryCode;
@property (nonatomic) NSString  *businessUrl;

@end
