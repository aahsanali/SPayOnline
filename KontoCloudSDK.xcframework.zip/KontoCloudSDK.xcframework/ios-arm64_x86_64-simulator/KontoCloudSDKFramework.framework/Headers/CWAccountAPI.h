//
//  CWAccountAPI.h
//  KontoCloudSDK
//
//  Created by Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWBaseAPI.h"

@class CWResponseBase;
@class CWAccountEnquiryRequest;
@class CWAccountEnquiryResponse;
@class CWFindAccountRequest;
@class CWFindAccountResponse;
@class CWCreateAccountRequest;
@class CWCreateAccountResponse;
@class CWUpdateAccountInformationRequest;
@class CWGetAccountInformationRequest;
@class CWGetAccountInformationResponse;
@class CWBalanceEnquiryRequest;
@class CWBalanceEnquiryResponse;
@class CWTransferAmountRequest;
@class CWTransferAmountResponse;
@class CWCalculateFeesRequest;
@class CWCalculateFeesResponse;
@class CWCheckLimitsRequest;
@class CWCheckLimitsResponse;
@class CWGetStoredPaymentOptionsRequest;
@class CWGetStoredPaymentOptionsResponse;
@class CWRequestMtanRequest;
@class CWCheckPaymentAccessCodeRequest;
@class CWInitAddStoredPaymentOptionRequest;
@class CWInitAddStoredPaymentOptionResponse;
@class CWCompleteAddStoredPaymentOptionRequest;
@class CWCompleteAddStoredPaymentOptionResponse;
@class CWDeleteStoredPaymentOptionRequest;
@class CWInitVerifyStoredPaymentOptionRequest;
@class CWCompleteVerifyStoredPaymentOptionRequest;
@class CWSetDefaultStoredPaymentOptionRequest;
@class CWGetProgramAccountsRequest;
@class CWGetProgramAccountsResponse;
@class CWGetAccountStateRequest;
@class CWGetAccountStateResponse;
@class CWRegisterAccountDeviceRequest;
@class CWVerifyTransferRecipientRequest;
@class CWGetSepaMandateRequest;
@class CWGetSepaMandateResponse;
@class CWVerifyMobilePhoneRequest;
@class CWGetTransferRecipientsRequest;
@class CWGetTransferRecipientsResponse;
@class CWUnregisterAccountDeviceRequest;

@interface CWAccountAPI : CWBaseAPI

- (void)createAccount:(CWCreateAccountRequest *)request completion:(void (^)(NSError *error, CWCreateAccountResponse *response))completionBlock;
- (void)updateAccountInformation:(CWUpdateAccountInformationRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)getAccountInformation:(CWGetAccountInformationRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWGetAccountInformationResponse *response))completionBlock;
- (void)accountEnquiry:(CWAccountEnquiryRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWAccountEnquiryResponse *response))completionBlock;
- (void)balanceEnquiry:(CWBalanceEnquiryRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWBalanceEnquiryResponse *response))completionBlock;
- (void)transferAmount:(CWTransferAmountRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWTransferAmountResponse *response))completionBlock;
- (void)findAccount:(CWFindAccountRequest *)request completion:(void (^)(NSError *error, CWFindAccountResponse *response))completionBlock;
- (void)calculateFees:(CWCalculateFeesRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWCalculateFeesResponse *response))completionBlock;
- (void)checkLimits:(CWCheckLimitsRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWCheckLimitsResponse *response))completionBlock;
- (void)getStoredPaymentOptions:(CWGetStoredPaymentOptionsRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWGetStoredPaymentOptionsResponse *response))completionBlock;
- (void)requestMtan:(CWRequestMtanRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)checkPaymentAccessCode:(CWCheckPaymentAccessCodeRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)initAddStoredPaymentOption:(CWInitAddStoredPaymentOptionRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWInitAddStoredPaymentOptionResponse *response))completionBlock;
- (void)completeAddStoredPaymentOption:(CWCompleteAddStoredPaymentOptionRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWCompleteAddStoredPaymentOptionResponse *response))completionBlock;
- (void)deleteStoredPaymentOption:(CWDeleteStoredPaymentOptionRequest *)request accno:(NSString *)accno storedPaymentOptionReference:(NSString *)ref completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)initVerifyStoredPaymentOption:(CWInitVerifyStoredPaymentOptionRequest *)request accno:(NSString *)accno storedPaymentOptionReference:(NSString *)ref completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)completeVerifyStoredPaymentOption:(CWCompleteVerifyStoredPaymentOptionRequest *)request accno:(NSString *)accno storedPaymentOptionReference:(NSString *)ref completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)setDefaultStoredPaymentOption:(CWSetDefaultStoredPaymentOptionRequest *)request accno:(NSString *)accno storedPaymentOptionReference:(NSString *)ref completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)getProgramAccounts:(CWGetProgramAccountsRequest *)request completion:(void (^)(NSError *error, CWGetProgramAccountsResponse *response))completionBlock;
- (void)getAccountState:(CWGetAccountStateRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWGetAccountStateResponse *response))completionBlock;
- (void)registerAccountDevice:(CWRegisterAccountDeviceRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)verifyTransferRecipient:(CWVerifyTransferRecipientRequest *)request completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)getSepaMandate:(CWGetSepaMandateRequest *)request accno:(NSString *)accno storedPaymentOptionReference:(NSString *)ref completion:(void (^)(NSError *error, CWGetSepaMandateResponse *response))completionBlock;
- (void)verifyMobilePhone:(CWVerifyMobilePhoneRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;
- (void)getTransferRecipients:(CWGetTransferRecipientsRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWGetTransferRecipientsResponse *response))completionBlock;
- (void)unregisterAccountDevice:(CWUnregisterAccountDeviceRequest *)request accno:(NSString *)accno completion:(void (^)(NSError *error, CWResponseBase *response))completionBlock;

@end

