//
//  CWCountryModel.h
//  KontoCloudSDK
//
//  Created by Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWCountryModel : NSObject

@property (nonatomic) NSString *countryName;
@property (nonatomic) NSString *countryCode;

- (instancetype)initWithDictionary:(NSDictionary *)dict;

@end
