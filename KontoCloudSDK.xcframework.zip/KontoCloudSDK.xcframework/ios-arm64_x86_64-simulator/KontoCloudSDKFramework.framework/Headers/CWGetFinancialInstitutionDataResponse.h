//
//  CWGetFinancialInstitutionDataResponse.h
//  KontoCloudSDK
//
//  Created by Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWGetFinancialInstitutionDataResponse : CWResponseBase

@property (nonatomic) NSString *name;
@property (nonatomic) NSString *addr1;
@property (nonatomic) NSString *addr2;
@property (nonatomic) NSString *city;
@property (nonatomic) NSString *state;
@property (nonatomic) NSString *countryName;
@property (nonatomic) NSString *countryCode;
@property (nonatomic) NSString *postCode;
@property (nonatomic) NSString *creditorIdentifier;

@end
