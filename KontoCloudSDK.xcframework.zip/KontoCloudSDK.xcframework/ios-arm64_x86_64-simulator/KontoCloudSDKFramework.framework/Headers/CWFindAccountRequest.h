//
//  CWFindAccountRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWFindAccountRequest : CWRequestBase

- (instancetype)initWithUserId:(NSString *)userId;

@end
