//
//  CWSecondaryEmailModel.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWSecondaryEmailModel : NSObject

@property (nonatomic) NSString *emailAddress;

- (instancetype)initWithDictionary:(NSDictionary *)dict;

- (BOOL)isEmailVerified;

@end
