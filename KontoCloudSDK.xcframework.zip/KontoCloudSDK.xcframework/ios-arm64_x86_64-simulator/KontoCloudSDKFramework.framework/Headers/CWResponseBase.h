//
//  CWResponseBase.h
//  KontoCloudSDK
//
//  Created by Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWResponseBaseInterface.h"

@interface CWResponseBase : NSObject <CWResponseBaseInterface>

@property (nonatomic) NSString *partnerReference;
@property (nonatomic) NSString *localDate;
@property (nonatomic) NSString *localTime;
@property (nonatomic) NSString *sysDate;
@property (nonatomic) NSString *sysTime;
@property (nonatomic) NSString *responseCode;
@property (nonatomic) NSString *responseDescription;

@end
