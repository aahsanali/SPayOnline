//
//  CWApiClientSettings.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CWApiClientSettingsInterface <NSObject>

@property (nonatomic) NSString *urlStr;
@property (nonatomic) NSString *partnerReferencePrefix;
@property (nonatomic) NSString *programCode;

@end
