//
//  KontoCloudSDKFramework.h
//  KontoCloudSDKFramework
//
//  Created by Kolya on 10/21/21.
//  Copyright © 2021 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for KontoCloudSDKFramework.
FOUNDATION_EXPORT double KontoCloudSDKFrameworkVersionNumber;

//! Project version string for KontoCloudSDKFramework.
FOUNDATION_EXPORT const unsigned char KontoCloudSDKFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KontoCloudSDKFramework/PublicHeader.h>
#import <KontoCloudSDKFramework/CWApiProvider.h>
#import <KontoCloudSDKFramework/CWApiProviderOption.h>
#import <KontoCloudSDKFramework/CWAccessTokenProvider.h>
#import <KontoCloudSDKFramework/CWDefaultAccessTokenProvider.h>

/*------------------------------ API headers ------------------------------*/
#import <KontoCloudSDKFramework/CWAccountAPI.h>
// Request/Response headers
#import <KontoCloudSDKFramework/CWAccountEnquiryRequest.h>
#import <KontoCloudSDKFramework/CWAccountEnquiryResponse.h>
#import <KontoCloudSDKFramework/CWFindAccountRequest.h>
#import <KontoCloudSDKFramework/CWFindAccountResponse.h>
#import <KontoCloudSDKFramework/CWCreateAccountRequest.h>
#import <KontoCloudSDKFramework/CWCreateAccountResponse.h>
#import <KontoCloudSDKFramework/CWUpdateAccountInformationRequest.h>
#import <KontoCloudSDKFramework/CWGetAccountInformationRequest.h>
#import <KontoCloudSDKFramework/CWGetAccountInformationResponse.h>
#import <KontoCloudSDKFramework/CWBalanceEnquiryRequest.h>
#import <KontoCloudSDKFramework/CWBalanceEnquiryResponse.h>
#import <KontoCloudSDKFramework/CWTransferAmountRequest.h>
#import <KontoCloudSDKFramework/CWTransferAmountResponse.h>
#import <KontoCloudSDKFramework/CWCalculateFeesRequest.h>
#import <KontoCloudSDKFramework/CWCalculateFeesResponse.h>
#import <KontoCloudSDKFramework/CWCheckLimitsRequest.h>
#import <KontoCloudSDKFramework/CWCheckLimitsResponse.h>
#import <KontoCloudSDKFramework/CWGetStoredPaymentOptionsRequest.h>
#import <KontoCloudSDKFramework/CWGetStoredPaymentOptionsResponse.h>
#import <KontoCloudSDKFramework/CWRequestMtanRequest.h>
#import <KontoCloudSDKFramework/CWCheckPaymentAccessCodeRequest.h>
#import <KontoCloudSDKFramework/CWInitAddStoredPaymentOptionRequest.h>
#import <KontoCloudSDKFramework/CWInitAddStoredPaymentOptionResponse.h>
#import <KontoCloudSDKFramework/CWCompleteAddStoredPaymentOptionRequest.h>
#import <KontoCloudSDKFramework/CWCompleteAddStoredPaymentOptionResponse.h>
#import <KontoCloudSDKFramework/CWDeleteStoredPaymentOptionRequest.h>
#import <KontoCloudSDKFramework/CWInitVerifyStoredPaymentOptionRequest.h>
#import <KontoCloudSDKFramework/CWCompleteVerifyStoredPaymentOptionRequest.h>
#import <KontoCloudSDKFramework/CWSetDefaultStoredPaymentOptionRequest.h>
#import <KontoCloudSDKFramework/CWGetProgramAccountsRequest.h>
#import <KontoCloudSDKFramework/CWGetProgramAccountsResponse.h>
#import <KontoCloudSDKFramework/CWGetAccountStateRequest.h>
#import <KontoCloudSDKFramework/CWGetAccountStateResponse.h>
#import <KontoCloudSDKFramework/CWRegisterAccountDeviceRequest.h>
#import <KontoCloudSDKFramework/CWVerifyTransferRecipientRequest.h>
#import <KontoCloudSDKFramework/CWGetSepaMandateRequest.h>
#import <KontoCloudSDKFramework/CWGetSepaMandateResponse.h>
#import <KontoCloudSDKFramework/CWVerifyMobilePhoneRequest.h>
#import <KontoCloudSDKFramework/CWGetTransferRecipientsRequest.h>
#import <KontoCloudSDKFramework/CWGetTransferRecipientsResponse.h>
#import <KontoCloudSDKFramework/CWUnregisterAccountDeviceRequest.h>
/////////////////////////////////////

#import <KontoCloudSDKFramework/CWUserAPI.h>
// Request/Response headers
#import <KontoCloudSDKFramework/CWChangePasswordRequest.h>
#import <KontoCloudSDKFramework/CWSendPasswordResetCodeRequest.h>
#import <KontoCloudSDKFramework/CWSendPasswordResetCodeResponse.h>
#import <KontoCloudSDKFramework/CWCheckUserUniquenessRequest.h>
#import <KontoCloudSDKFramework/CWCheckUserUniquenessResponse.h>
#import <KontoCloudSDKFramework/CWValidatePasswordRequest.h>
#import <KontoCloudSDKFramework/CWGetSecondaryEmailsRequest.h>
#import <KontoCloudSDKFramework/CWGetSecondaryEmailsResponse.h>
#import <KontoCloudSDKFramework/CWCreateSecondaryEmailRequest.h>
#import <KontoCloudSDKFramework/CWEditSecondaryEmailRequest.h>
#import <KontoCloudSDKFramework/CWDeleteSecondaryEmailRequest.h>
#import <KontoCloudSDKFramework/CWSetMainEmailRequest.h>
////////////////////////////////////

#import <KontoCloudSDKFramework/CWSettingsAPI.h>
// Request/Response headers
#import <KontoCloudSDKFramework/CWGetCountriesRequest.h>
#import <KontoCloudSDKFramework/CWGetCountriesResponse.h>
#import <KontoCloudSDKFramework/CWGetFinancialInstitutionDataRequest.h>
#import <KontoCloudSDKFramework/CWGetFinancialInstitutionDataResponse.h>
////////////////////////////////////

#import <KontoCloudSDKFramework/CWPaymentAPI.h>
// Request/Response headers
#import <KontoCloudSDKFramework/CWAuthorizeRequest.h>
#import <KontoCloudSDKFramework/CWAuthorizeResponse.h>
#import <KontoCloudSDKFramework/CWCaptureRequest.h>
#import <KontoCloudSDKFramework/CWCaptureResponse.h>
#import <KontoCloudSDKFramework/CWCancelRequest.h>
#import <KontoCloudSDKFramework/CWCancelResponse.h>
#import <KontoCloudSDKFramework/CWPayToAccountRequest.h>
#import <KontoCloudSDKFramework/CWPayToAccountResponse.h>
#import <KontoCloudSDKFramework/CWKcCompleteAuthorizeRequest.h>
#import <KontoCloudSDKFramework/CWKcCompleteAuthorizeResponse.h>
#import <KontoCloudSDKFramework/CWGetPaymentInformationRequest.h>
#import <KontoCloudSDKFramework/CWGetPaymentInformationResponse.h>
#import <KontoCloudSDKFramework/CWInitAuthorizeRequest.h>
#import <KontoCloudSDKFramework/CWInitAuthorizeResponse.h>
#import <KontoCloudSDKFramework/CWCompleteAuthorizeRequest.h>
#import <KontoCloudSDKFramework/CWCompleteAuthorizeResponse.h>
////////////////////////////////////

#import <KontoCloudSDKFramework/CWAuthenticationAPI.h>
// Request/Response headers
#import <KontoCloudSDKFramework/CWAccessTokenResponse.h>
////////////////////////////////////

// Other headers
#import <KontoCloudSDKFramework/CWApiClientSettingsInterface.h>
#import <KontoCloudSDKFramework/CWPaymentForm.h>
#import <KontoCloudSDKFramework/CWFormStyle.h>
#import <KontoCloudSDKFramework/CWLookups.h>

