//
//  CWEntryModel.h
//  KontoCloudSDK
//
//  Created by Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWEntryModel : NSObject

@property (nonatomic) NSString *entryType;
@property (nonatomic) NSString *bookingDate;
@property (nonatomic) NSString *bookingTime;
@property (nonatomic) NSString *valueDate;
@property (nonatomic) NSString *valueTime;
@property (nonatomic) NSNumber *sourceAmount;
@property (nonatomic) NSString *sourceCurrCode;
@property (nonatomic) NSNumber *amount;
@property (nonatomic) NSString *currCode;
@property (nonatomic) NSNumber *exchangeRate;
@property (nonatomic) NSNumber *balance;
@property (nonatomic) NSString *entryIndicator;
@property (nonatomic) NSString *entryDescription;
@property (nonatomic) NSString *name;
@property (nonatomic) NSString *reference;

- (instancetype)initWithDictionary:(NSDictionary *)dict;

@end
