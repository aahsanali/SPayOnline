//
//  CWBalanceEnquiryResponse.h
//  KontoCloudSDK
//
//  Created by Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWBalanceEnquiryResponse : CWResponseBase

@property (nonatomic) NSNumber *psBal;
@property (nonatomic) NSNumber *avlBal;
@property (nonatomic) NSNumber *bkBal;
@property (nonatomic) NSNumber *blkAmt;
@property (nonatomic) NSString *currCode;

@end
