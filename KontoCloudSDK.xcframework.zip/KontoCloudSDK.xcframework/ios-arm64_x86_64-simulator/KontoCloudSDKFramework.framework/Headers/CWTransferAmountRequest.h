//
//  CWTransferAmountRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWTransferAmountRequest : CWRequestBase

@property (nonatomic) NSString *programAccno;
@property (nonatomic) NSString *clientIpAddress;

- (instancetype)initWithAccnoType:(NSString *)accnoType carrierNumber:(NSString *)carrierNumber transferAmount:(NSNumber *)transferAmount transferCurrCode:(NSString *)transferCurrCode transferUsage:(NSString *)transferUsage feePayer:(NSNumber *)feePayer;

@end
