//
//  CWAccountEnquiryResponse.h
//  KontoCloudSDK
//
//  Created by Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"
#import "CWEntryModel.h"

@interface CWAccountEnquiryResponse : CWResponseBase

@property (nonatomic) NSArray <CWEntryModel *> *entries;
@property (nonatomic) NSNumber *count;

@end
