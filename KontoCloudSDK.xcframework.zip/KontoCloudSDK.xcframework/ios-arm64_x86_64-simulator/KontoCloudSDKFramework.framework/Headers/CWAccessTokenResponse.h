//
//  CWAccessTokenResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWResponseBaseInterface.h"

@interface CWAccessTokenResponse : NSObject <CWResponseBaseInterface>

@property (nonatomic) NSString *access_token;
@property (nonatomic) NSNumber *expires_in;
@property (nonatomic) NSString *refresh_token;
@property (nonatomic) NSString *token_type;

@end
