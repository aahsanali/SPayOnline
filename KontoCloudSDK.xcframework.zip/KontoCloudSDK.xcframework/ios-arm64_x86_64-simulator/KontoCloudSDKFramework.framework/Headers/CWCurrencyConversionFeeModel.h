//
//  CWCurrencyConversionFeeModel.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWCurrencyConversionFeeModel : NSObject

@property (nonatomic) NSString *fromCurrencyCode;
@property (nonatomic) NSString *toCurrencyCode;
@property (nonatomic) NSNumber *flatValue;
@property (nonatomic) NSNumber *percentageValue;
@property (nonatomic) NSNumber *percentageAmount;

- (instancetype)initWithDictionary:(NSDictionary *)dict;

@end
