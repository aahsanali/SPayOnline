//
//  CWSettingsAPI.h
//  KontoCloudSDK
//
//  Created by Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWBaseAPI.h"

@class CWGetCountriesRequest;
@class CWGetCountriesResponse;
@class CWGetFinancialInstitutionDataRequest;
@class CWGetFinancialInstitutionDataResponse;

@interface CWSettingsAPI : CWBaseAPI

- (void)getCountries:(CWGetCountriesRequest *)request completion:(void (^)(NSError *error, CWGetCountriesResponse *response))completionBlock;
- (void)getgetFinancialInstitutionData:(CWGetFinancialInstitutionDataRequest *)request completion:(void (^)(NSError *error, CWGetFinancialInstitutionDataResponse *response))completionBlock;

@end
