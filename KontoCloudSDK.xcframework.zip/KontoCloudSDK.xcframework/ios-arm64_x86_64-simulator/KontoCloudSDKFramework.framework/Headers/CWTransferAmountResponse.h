//
//  CWTransferAmountResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWTransferAmountResponse : CWResponseBase

@property (nonatomic) NSString *programAccno;
@property (nonatomic) NSString *accno;
@property (nonatomic) NSString *recAccno;
@property (nonatomic) NSString *uniqueReference;
@property (nonatomic) NSNumber *tansferAmount;
@property (nonatomic) NSString *transferCurrCode;
@property (nonatomic) NSNumber *bookedAmount;
@property (nonatomic) NSString *bookedCurrCode;
@property (nonatomic) NSNumber *fxRate;

@end


