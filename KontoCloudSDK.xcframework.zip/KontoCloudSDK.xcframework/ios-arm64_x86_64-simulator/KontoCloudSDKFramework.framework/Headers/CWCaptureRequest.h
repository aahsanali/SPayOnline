//
//  CWCaptureRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWCaptureRequest : CWRequestBase

@property (nonatomic) NSNumber *modifiedAmount;
@property (nonatomic) NSString *modifiedAmountCurrCode;
@property (nonatomic) NSString *modifiedUsage;
@property (nonatomic) NSNumber *modifiedFeeAmount;
@property (nonatomic) NSString *modifiedFeeCurrCode;
@property (nonatomic) NSString *custom1;
@property (nonatomic) NSString *custom2;
@property (nonatomic) NSString *custom3;

@end
