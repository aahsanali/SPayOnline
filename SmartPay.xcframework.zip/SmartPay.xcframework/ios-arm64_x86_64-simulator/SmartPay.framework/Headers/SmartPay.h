//
//  SmartPay.h
//  SmartPay
//
//  Created by Vadim Khomenok on 8/27/20.
//  Copyright © 2020 NS. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SmartPay.
FOUNDATION_EXPORT double SmartPayVersionNumber;

//! Project version string for SmartPay.
FOUNDATION_EXPORT const unsigned char SmartPayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmartPay/PublicHeader.h>


