//
//  CWFeeModel.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWFeeModel : NSObject

@property (nonatomic) NSString *name;
@property (nonatomic) NSNumber *feeAmount;
@property (nonatomic) NSString *feeCurrCode;
@property (nonatomic) NSNumber *totalFeeValue;
@property (nonatomic) NSNumber *totalMaximumFee;
@property (nonatomic) NSNumber *totalMinimumFee;
@property (nonatomic) NSString *feeId;

- (instancetype)initWithDictionary:(NSDictionary *)dict;

- (BOOL)isWaived;
- (NSInteger)feeUnitCode;

@end
