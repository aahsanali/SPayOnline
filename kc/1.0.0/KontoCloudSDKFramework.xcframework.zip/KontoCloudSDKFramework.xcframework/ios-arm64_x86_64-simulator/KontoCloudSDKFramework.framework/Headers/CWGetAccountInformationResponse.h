//
//  CWGetAccountInformationResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWGetAccountInformationResponse : CWResponseBase

@property (nonatomic) NSString *accno;
@property (nonatomic) NSString *title;
@property (nonatomic) NSString *lastName;
@property (nonatomic) NSString *firstName;
@property (nonatomic) NSString *addr1;
@property (nonatomic) NSString *addr2;
@property (nonatomic) NSString *city;
@property (nonatomic) NSString *state;
@property (nonatomic) NSString *countryName;
@property (nonatomic) NSString *countryCode;
@property (nonatomic) NSString *postCode;
@property (nonatomic) NSDate   *dob;
@property (nonatomic) NSString *landlinePhone;
@property (nonatomic) NSString *mobilePhone;
@property (nonatomic) NSString *emailAddress;
@property (nonatomic) NSString *culture;
@property (nonatomic) NSString *timeZone;
@property (nonatomic) NSString *correspondenceAddr1;
@property (nonatomic) NSString *correspondenceAddr2;
@property (nonatomic) NSString *correspondenceCity;
@property (nonatomic) NSString *correspondenceState;
@property (nonatomic) NSString *correspondenceCountryName;
@property (nonatomic) NSString *correspondenceCountryCode;
@property (nonatomic) NSString *correspondencePostCode;
@property (nonatomic) NSString *currCode;
@property (nonatomic) NSString *accTypeName;
@property (nonatomic) NSString *accTypeCode;
@property (nonatomic) NSString *statusCode;
@property (nonatomic) NSString *accFlowStatusCode;
@property (nonatomic) NSDate   *lastLoginDate;
@property (nonatomic) NSDate   *lastLoginTime;
@property (nonatomic) NSString *businessCompanyName;
@property (nonatomic) NSString *businessCompanyType;
@property (nonatomic) NSString *businessCompanyRegistrationNumber;
@property (nonatomic) NSString *businessCompanyRegistrationCountryCode;
@property (nonatomic) NSString *businessAddr1;
@property (nonatomic) NSString *businessAddr2;
@property (nonatomic) NSString *businessCity;
@property (nonatomic) NSString *businessPostCode;
@property (nonatomic) NSString *businessCountryCode;
@property (nonatomic) NSString *businessUrl;

- (BOOL)useDifferentCorrespondenceAddress;
- (BOOL)isEmailVerified;
- (BOOL)isMobilePhoneVerified;
- (BOOL)isMtanEnabled;
- (BOOL)isBusinessUser;

@end
