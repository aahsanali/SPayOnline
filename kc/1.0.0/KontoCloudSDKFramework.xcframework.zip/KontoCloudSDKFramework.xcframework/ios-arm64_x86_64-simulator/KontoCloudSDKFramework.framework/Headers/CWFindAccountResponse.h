//
//  CWFindAccountResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWFindAccountResponse : CWResponseBase

@property (nonatomic) NSString *accno;

@end
