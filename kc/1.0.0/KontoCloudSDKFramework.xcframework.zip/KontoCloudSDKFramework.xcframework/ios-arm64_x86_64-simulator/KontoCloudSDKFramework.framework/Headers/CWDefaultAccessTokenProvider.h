//
//  CWDefaultAccessTokenProvider.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWAccessTokenProvider.h"

@interface CWDefaultAccessTokenProvider : NSObject <CWAccessTokenProvider>

@end
