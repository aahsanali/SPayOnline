//
//  CWGetAccountInformationRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWGetAccountInformationRequest : CWRequestBase

- (instancetype)initWithAccnoType:(NSString *)accnoType;

@end
