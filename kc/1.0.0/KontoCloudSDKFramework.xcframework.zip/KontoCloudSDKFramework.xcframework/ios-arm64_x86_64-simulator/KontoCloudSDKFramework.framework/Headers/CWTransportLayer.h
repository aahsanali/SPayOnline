//
//  CWTransportLayer.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 15.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWAccessTokenProvider.h"
#import "CWApiClientSettingsInterface.h"

@interface CWTransportLayer : NSObject

- (instancetype)initWithApiAccessTokenProvider:(id <CWAccessTokenProvider>)accessTokenProvider settings:(id <CWApiClientSettingsInterface>)setting;

- (void)loadRequestWithURLComponents:(NSURLComponents *)urlComponents
                              method:(NSString *)method
                              params:(NSDictionary *)params
                          completion:(void (^)(id responseObject, NSError *error))completionBlock;

- (void)loadRequestWithFormURLComponents:(NSURLComponents *)urlComponents
                                  params:(NSDictionary *)params
                              completion:(void (^)(id responseObject, NSError *error))completionBlock;

@end
