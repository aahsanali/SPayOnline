//
//  CWCreateAccountResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWCreateAccountResponse : CWResponseBase

@property (nonatomic) NSString *productCode;
@property (nonatomic) NSString *accTypeCode;
@property (nonatomic) NSString *custCode;
@property (nonatomic) NSString *externalAccountReference;
@property (nonatomic) NSString *accno;
@property (nonatomic) NSString *statusCode;
@property (nonatomic) NSString *accFlowStatusCode;
@property (nonatomic) NSDate   *validFrom;
@property (nonatomic) NSDate   *validUntil;

@end
