//
//  CWInitAuthorizeResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 24.10.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWInitAuthorizeResponse : CWResponseBase

@property (nonatomic) NSString *programAccno;
@property (nonatomic) NSString *accno;
@property (nonatomic) NSString *uniqueReference;
@property (nonatomic) NSString *authorizationToken;
@property (nonatomic) NSString *paymentOptionCode;
@property (nonatomic) NSNumber *presentationAmount;
@property (nonatomic) NSString *presentationCurrCode;
@property (nonatomic) NSString *presentationUsage;
@property (nonatomic) NSString *custom1;
@property (nonatomic) NSString *custom2;
@property (nonatomic) NSString *custom3;
@property (nonatomic) NSString *statusCode;
@property (nonatomic) NSString *statusReason;

@end
