//
//  CWInitAuthorizeRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 24.10.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWInitAuthorizeRequest : CWRequestBase

@property (nonatomic) NSString *programAccno;
@property (nonatomic) NSString *accno;
@property (nonatomic) NSString *accnoType;
@property (nonatomic) NSString *storedPaymentOptionReference;
@property (nonatomic) NSString *paymentOptionCode;
@property (nonatomic) NSNumber *presentationAmount;
@property (nonatomic) NSString *presentationCurrCode;
@property (nonatomic) NSString *presentationUsage;
@property (nonatomic) NSNumber *feeAmount;
@property (nonatomic) NSString *feeCurrCode;
@property (nonatomic) BOOL useDifferentBillingAddress;
@property (nonatomic) NSString *customerFullName;
@property (nonatomic) NSString *addr1;
@property (nonatomic) NSString *addr2;
@property (nonatomic) NSString *addr3;
@property (nonatomic) NSString *houseNumber;
@property (nonatomic) NSString *city;
@property (nonatomic) NSString *state;
@property (nonatomic) NSString *countryCode;
@property (nonatomic) NSString *postCode;
@property (nonatomic) NSString *ipAddr;
@property (nonatomic) NSString *custom1;
@property (nonatomic) NSString *custom2;
@property (nonatomic) NSString *custom3;
@property (nonatomic) NSString *externalChannelReference;
@property (nonatomic) NSString *mandateReference;
@property (nonatomic) NSDate *mandateSignedDate;
@property (nonatomic) NSDictionary *criteria;
@property (nonatomic) NSString *emailAddress;

@end
