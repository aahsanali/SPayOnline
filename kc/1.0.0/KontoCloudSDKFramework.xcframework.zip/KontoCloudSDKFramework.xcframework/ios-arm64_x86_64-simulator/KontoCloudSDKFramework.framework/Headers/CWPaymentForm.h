//
//  CWPaymentForm.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 22.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, PaymentFormMode) {
    FormMode_UNDEFINED = -1,
    FormMode_REGISTRATION = 0,
    FormMode_PAYMENT = 1
};

typedef NS_ENUM(NSInteger, PaymentProviderMode) {
    ProviderMode_UNDEFINED = -1,
    ProviderMode_TEST = 0,
    ProviderMode_LIVE = 1
};

typedef NS_ENUM(NSUInteger, PaymentOptionCode) {
    PaymentOption_VISA,
    PaymentOption_MASTERCARD,
    PaymentOption_BANK_ACCOUNT,
    PaymentOption_PAYU,
    PaymentOption_PAYPAL,
    PaymentOption_AMEX,
    PaymentOption_MAESTRO,
    PaymentOption_DISCOVER,
    PaymentOption_CARDS
};

typedef NS_ENUM(NSUInteger, PaymentFormElement) {
    PaymentFormElement_CardNumber,
    PaymentFormElement_Expiry,
    PaymentFormElement_CardHolder,
    PaymentFormElement_CVV,
    PaymentFormElement_All
};

typedef NS_ENUM(NSUInteger, PaymentOptionProvider) {
    PaymentOptionProvider_Payon,
    PaymentOptionProvider_PaymentOS,
    PaymentOptionProvider_Paypal,
    PaymentOptionProvider_Cybersource,
    PaymentOptionProvider_CybersourceWithTokenEx,
    PaymentOptionProvider_VestaWithTokenEx,
    PaymentOptionProvider_Sepa,
    PaymentOptionProvider_PayonWithPCIProxy
};

@protocol onBeforeSubmitArgInterface <NSObject>

@property (nonatomic, nullable) NSString *accountHolder;
@property (nonatomic, nullable) NSString *iban;
@property (nonatomic, nullable) NSString *paymentOptionCode;
@property (nonatomic, nullable) NSDictionary *originArgs;

- (void)preventSubmit;

@end

@class CWFormStyle;

@interface CWPaymentForm : UIView

@property (nonatomic) PaymentFormMode mode;
@property (nonatomic) PaymentProviderMode providerMode;
@property (nonatomic) PaymentOptionProvider paymentProvider;
@property (nonatomic) BOOL showStorePaymentMethod; 
@property (nonatomic) NSString * _Nullable redirectURL;
@property (nonatomic) NSString * _Nullable apiURL;
@property (nonatomic, copy, nullable) void (^onFormLoaded)(void);
@property (nonatomic, copy, nullable) void (^onSuccessCallback)(NSString * _Nullable paymentOptionCode,
                                                                NSString * _Nullable authorizationToken,
                                                                NSString * _Nullable additionalParam);
@property (nonatomic, copy, nullable) void (^onError)(NSString * _Nullable errorMessage);
@property (nonatomic, copy, nullable) void (^onCancel)(NSString * _Nullable message);
@property (nonatomic, copy, nullable) void (^onBeforeSubmitCallback)(void) DEPRECATED_MSG_ATTRIBUTE("use onBeforeSubmitCallbackWithArg instead");
@property (nonatomic, copy, nullable) void (^onBeforeSubmitCallbackWithArg)(_Nullable id<onBeforeSubmitArgInterface> args);

- (void)renderWithPaymentOptionCode:(PaymentOptionCode)paymentOptionCode authorizationToken:(NSString * _Nonnull)authToken formStyle:(nullable CWFormStyle *)formStyle;
- (void)renderWithPaymentOptions:(NSArray<NSString *> * _Nonnull)paymentOptions authorizationToken:(NSString * _Nonnull)authToken formStyle:(nullable CWFormStyle *)formStyle;

- (void)setElement:(PaymentFormElement)element visible:(BOOL)isVisible;
- (void)validateElement:(PaymentFormElement)element
               callback:(void (^_Nonnull)(PaymentFormElement element, BOOL isValid))validationCallback;

- (void)submit;
- (void)acceptAndSubmit;

@end
