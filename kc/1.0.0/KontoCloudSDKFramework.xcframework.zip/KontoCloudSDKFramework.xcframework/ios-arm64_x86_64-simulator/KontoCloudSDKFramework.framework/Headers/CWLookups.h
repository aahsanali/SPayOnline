//
//  CWLookups.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 11.08.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWLookups : NSObject

+ (NSString *)SDKVersion;
+ (NSString *)PaymentOptionCode_MasterCard;
+ (NSString *)PaymentOptionCode_Visa;
+ (NSString *)PaymentOptionCode_BankAccount;
+ (NSString *)PaymentOptionCode_PayU;
+ (NSString *)PaymentOptionCode_PayPal;
+ (NSString *)PaymentOptionCode_Amex;
+ (NSString *)PaymentOptionCode_Maestro;
+ (NSString *)PaymentOptionCode_Discover;

@end
