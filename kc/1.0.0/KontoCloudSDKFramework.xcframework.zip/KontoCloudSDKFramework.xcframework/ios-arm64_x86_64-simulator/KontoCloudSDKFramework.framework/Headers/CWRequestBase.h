//
//  CWRequestBase.h
//  KontoCloudSDK
//
//  Created by Nick on 14.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#ifndef _CWRequestBase_
#define _CWRequestBase_

#import <Foundation/Foundation.h>
#import "CWRequestBaseInterface.h"

@interface CWRequestBase : NSObject <CWRequestBaseInterface>

//@property (nonatomic) NSString *PROGRAM_CODE;
//@property (nonatomic) NSString *PARTNER_REFERENCE_PREFIX;

@property (nonatomic, readonly) NSDateFormatter *baseDateFormatter;
@property (nonatomic, readonly) NSDateFormatter *baseTimeFormatter;

- (NSString *)convertInteger:(NSInteger)integerValue;
- (NSString *)convertNumber:(NSNumber *)number;
- (NSString *)convertDouble:(double)doubleValue;
- (NSString *)convertBoolean:(BOOL)boolValue;
- (NSString *)convertLocalDate:(NSDate *)date;
- (NSString *)convertLocalTime:(NSDate *)time;

@end

#endif
