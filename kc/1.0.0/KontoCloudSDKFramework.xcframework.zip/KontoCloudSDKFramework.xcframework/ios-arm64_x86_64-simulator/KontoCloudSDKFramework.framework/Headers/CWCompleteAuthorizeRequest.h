//
//  CWCompleteAuthorizeRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 24.10.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWCompleteAuthorizeRequest : CWRequestBase

@property (nonatomic) NSString *authorizationToken;
@property (nonatomic) NSString *externalChannelReference;
@property (nonatomic) BOOL useDifferentBillingAddress;
@property (nonatomic) NSString *customerFullName;
@property (nonatomic) NSString *addr1;
@property (nonatomic) NSString *addr2;
@property (nonatomic) NSString *addr3;
@property (nonatomic) NSString *houseNumber;
@property (nonatomic) NSString *city;
@property (nonatomic) NSString *state;
@property (nonatomic) NSString *countryCode;
@property (nonatomic) NSString *postCode;
@property (nonatomic) NSDictionary *criteria;

@end
