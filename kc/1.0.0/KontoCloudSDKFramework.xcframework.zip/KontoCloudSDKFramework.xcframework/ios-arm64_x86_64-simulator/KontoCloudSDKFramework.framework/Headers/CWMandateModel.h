//
//  CWMandateModel.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWMandateModel : NSObject

@property (nonatomic) NSString *mandateReference;
@property (nonatomic) NSDate   *mandateSignedDate;
@property (nonatomic) NSString *financialInstitutionName;
@property (nonatomic) NSString *financialInstitutionAddr1;
@property (nonatomic) NSString *financialInstitutionAddr2;
@property (nonatomic) NSString *financialInstitutionCity;
@property (nonatomic) NSString *financialInstitutionState;
@property (nonatomic) NSString *financialInstitutionCountryName;
@property (nonatomic) NSString *financialInstitutionCountryCode;
@property (nonatomic) NSString *financialInstitutionPostCode;
@property (nonatomic) NSString *financialInstitutionCreditorIdentifier;

- (instancetype)initWithDictionary:(NSDictionary *)dict;

@end
