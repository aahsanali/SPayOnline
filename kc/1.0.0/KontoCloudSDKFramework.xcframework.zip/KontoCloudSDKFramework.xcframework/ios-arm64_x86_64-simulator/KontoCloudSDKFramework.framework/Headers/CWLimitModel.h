//
//  CWLimitModel.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWLimitModel : NSObject

@property (nonatomic) NSString *name;
@property (nonatomic) NSNumber *limitValue;
@property (nonatomic) NSString *limitCurrCode;
@property (nonatomic) NSString *limitMessage;
@property (nonatomic) NSNumber *totalMaximumValue;
@property (nonatomic) NSNumber *totalMinimumValue;
@property (nonatomic) NSNumber *totalWarningValue;

- (instancetype)initWithDictionary:(NSDictionary *)dict;

- (BOOL)isError;
- (NSInteger)limitUnitCode;
- (NSInteger)limitPeriodCode;

@end
