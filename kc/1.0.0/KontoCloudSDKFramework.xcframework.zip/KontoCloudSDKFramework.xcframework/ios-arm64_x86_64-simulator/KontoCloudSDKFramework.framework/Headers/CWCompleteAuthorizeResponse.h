//
//  CWCompleteAuthorizeResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 24.10.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"

@interface CWCompleteAuthorizeResponse : CWResponseBase

@property (nonatomic) NSString *initiatorAccno;
@property (nonatomic) NSString *accno;
@property (nonatomic) NSString *uniqueReference;
@property (nonatomic) NSString *storedPaymentOptionReference;
@property (nonatomic) NSNumber *processedAmount;
@property (nonatomic) NSString *processedCurrCode;
@property (nonatomic) NSString *statusCode;
@property (nonatomic) NSString *statusReason;

@end
