//
//  CWPaymentOptionModel.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWAddressModel.h"
#import "CWMandateModel.h"

@interface CWPaymentOptionModel : NSObject

@property (nonatomic) NSString *name;
@property (nonatomic) NSString *code;
@property (nonatomic) NSString *carrierNumber;
@property (nonatomic) NSString *reference;
@property (nonatomic) NSString *paymentGroup;
@property (nonatomic) NSString *paymentGroupCode;
@property (nonatomic) NSString *paymentSubGroup;
@property (nonatomic) NSString *paymentSubGroupCode;
@property (nonatomic) NSString *bankCode;
@property (nonatomic) NSString *statusCode;
@property (nonatomic) CWAddressModel *billingAddress;
@property (nonatomic) CWMandateModel *mandate;

- (instancetype)initWithDictionary:(NSDictionary *)dict;

- (NSInteger)expiryMonth;
- (NSInteger)expiryYear;
- (BOOL)isVerifiable;
- (BOOL)isDefault;

@end
