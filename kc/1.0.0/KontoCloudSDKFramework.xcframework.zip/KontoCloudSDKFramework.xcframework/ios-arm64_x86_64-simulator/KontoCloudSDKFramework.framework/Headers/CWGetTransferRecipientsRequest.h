//
//  CWGetTransferRecipientsRequest.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWRequestBase.h"

@interface CWGetTransferRecipientsRequest : CWRequestBase

- (instancetype)initWithAccnoType:(NSString *)accnoType recipientId:(NSString *)recipientId top:(NSNumber *)top skip:(NSNumber *)skip;

@end
