//
//  CWResponseBaseInterface.h
//  KontoCloudSDK
//
//  Created by Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CWResponseBaseInterface <NSObject>

- (instancetype)initWithJSONObject:(id)jsonObj;

@end
