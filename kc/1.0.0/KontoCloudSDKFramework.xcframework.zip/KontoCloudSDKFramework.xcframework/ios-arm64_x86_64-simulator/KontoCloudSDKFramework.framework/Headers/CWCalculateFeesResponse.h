//
//  CWCalculateFeesResponse.h
//  KontoCloudSDK
//
//  Created by Kolya Nick on 16.05.17.
//  Copyright © 2017 ContoWorks. All rights reserved.
//

#import "CWResponseBase.h"
#import "CWFeeModel.h"
#import "CWCurrencyConversionFeeModel.h"

@interface CWCalculateFeesResponse : CWResponseBase

@property (nonatomic) NSArray <CWFeeModel *> *fees;
@property (nonatomic) CWCurrencyConversionFeeModel *currencyConversionFee;

@end
